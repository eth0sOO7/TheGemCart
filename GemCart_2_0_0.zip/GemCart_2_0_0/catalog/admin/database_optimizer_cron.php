<?php
/* 
  $Id$ 
  The Gem Cart, the Diamond of E-Commerce shopping cart Solutions 
  TheGemCart, GemCart and The Gem Cart are registered service marks of GemCart Inc. 2012. 
  All rights reserved. 
  http://www.thegemcart.com 
  Copyright 2012 Gem Cart 
  Copyright (c) 2010 osCommerce (portions) 
  Released under the GNU General Public License 
  Version 2.0 2012-05-01 0eth0s & JoDaNo
*/ 
/*************************** OPTIONS AND EDITABLE STRINGS ****************************************/
$message = 'Store database has been optimized.';
$subject = 'Database %s has been optimized';
$verbose = true;  //show results
/*************** DON"T EDIT BELOW HERE UNLESS YOU UNDERSTAND THE CONSEQUENCES ********************/
include('includes/configure.php');
if (!($link = mysql_connect(DB_SERVER, DB_SERVER_USERNAME, DB_SERVER_PASSWORD) or die("Unable to connect to database server!"))) {
    if ($verbose) echo ERROR_FAILED_DB_CONNECTION . "\r\n<br>";
    exit(ERROR_FAILED_DB_CONNECTION);
}
mysql_select_db(DB_DATABASE);
$config = array();
$config_query = mysql_query("select * FROM configuration WHERE (configuration_key LIKE 'DATABASE_OPTIMIZER%' or configuration_key = 'STORE_OWNER_EMAIL_ADDRESS')");
while ($loadconfig = mysql_fetch_array($config_query, MYSQL_ASSOC)) {
    switch ($loadconfig['configuration_key']) {
        case 'DATABASE_OPTIMIZER_ENABLE':        $config['main_switch'] = $loadconfig['configuration_value']; break;
        case 'DATABASE_OPTIMIZER_PERIOD':        $config['period'] = $config['optimize'] =$loadconfig['configuration_value']; break;
        case 'DATABASE_OPTIMIZER_ANALYZE':       $config['analyze'] = $loadconfig['configuration_value']; break;
        case 'DATABASE_OPTIMIZER_CUSTOMERS':     $config['customers'] = $loadconfig['configuration_value']; break;
        case 'DATABASE_OPTIMIZER_CUSTOMERS_OLD': $config['customers_old'] = $loadconfig['configuration_value']; break;
        case 'DATABASE_OPTIMIZER_ORDERS_CC':     $config['orders_cc'] = $loadconfig['configuration_value']; break;
        case 'DATABASE_OPTIMIZER_SESSIONS':      $config['sessions'] = $loadconfig['configuration_value']; break;
        case 'DATABASE_OPTIMIZER_USER_TRACKING': $config['usertracking'] = $loadconfig['configuration_value']; break;
        case 'STORE_OWNER_EMAIL_ADDRESS':        $config['email_address'] = $loadconfig['configuration_value']; break;
    }
}
if ($config['main_switch'] == 'true') {
    $query = mysql_query("select last_update from database_optimizer");
    $mainDate = mysql_fetch_array($query, MYSQL_ASSOC);
    $dateArray  = explode("-",$mainDate['last_update']);
    $date1Int = mktime(0,0,0, $dateArray[1], $dateArray[2], $dateArray[0]);
    $daysLastRan = abs(floor((time() - $date1Int )/(60*60*24)));
    $wasUpdated = false;
    require(DIR_WS_MODULES . 'database_optimizer_common.php');
}
mysql_close($link);
function Get_DB_Size($database) {
    mysql_select_db( $database );
    $result = mysql_query("SHOW TABLE STATUS");
    $dbsize = 0;
    while( $row = mysql_fetch_array( $result, MYSQL_ASSOC ) ) {
        $dbsize += $row[ "Data_length" ] + $row[ "Index_length" ];
    }
    return $dbsize;
}