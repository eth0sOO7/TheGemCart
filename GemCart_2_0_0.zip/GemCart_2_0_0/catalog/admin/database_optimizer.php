<?php
/* 
  $Id$ 
  The Gem Cart, the Diamond of E-Commerce shopping cart Solutions 
  TheGemCart, GemCart and The Gem Cart are registered service marks of GemCart Inc. 2012. 
  All rights reserved. 
  http://www.thegemcart.com 
  Copyright 2012 Gem Cart 
  Copyright (c) 2010 osCommerce (portions) 
  Released under the GNU General Public License 
  Version 2.0 2012-05-01 0eth0s & JoDaNo
*/ 
  require('includes/application_top.php');
  $actionRunOptimizer  = ((isset($_POST['action_run_optimizer']) && $_POST['action_run_optimizer'] == 'process') ? true : false);
  $currentVersion = '';
  $message = '';
  /********************** BEGIN VERSION CHECKER *********************/
  if (file_exists(DIR_WS_FUNCTIONS . 'version_checker.php')) {
      require(DIR_WS_LANGUAGES . $language . '/version_checker.php');
      require(DIR_WS_FUNCTIONS . 'version_checker.php');
      $contribPath = 'http://addons.oscommerce.com/info/4441';
      $currentVersion = 'Database Optimizer V 1.2';
      $contribName = 'Database Optimizer V';
      $versionStatus = '';
  }
  /********************** END VERSION CHECKER *********************/
  if (isset($_POST['action']))  {
      /********************** CHECK THE VERSION ***********************/
      if ($_POST['action'] == 'getversion') {
          if (isset($_POST['version_check']) && $_POST['version_check'] == 'on') {
              $versionStatus = AnnounceVersion($contribPath, $currentVersion, $contribName);
          }
      }
  }
  else if ($actionRunOptimizer) {
      require(DIR_WS_MODULES . FILENAME_DATABASE_OPTIMIZER);
      if (! $optionSelected) {
          $messageStack->add(ERROR_NO_OPTION_SELECTED, 'error');
      }
  }
  require(DIR_WS_INCLUDES . 'template_top.php');
?>
<style type="text/css">
td.HTC_subHead {color: sienna; font-size: 14px; }
table.BorderedBox {border: ridge #ddd 3px; background-color: #eee; }
table.BorderedBoxWhite {border: ridge #ddd 3px; background-color: #fff; }
table.BorderedBoxLight {border: ridge #ddd 3px; background-color: #E6E6E6; }
tr.Header { background-color: #eee; }
.ds_small { font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight:bold }
</style>
<script type="text/javascript"> <!--
function popupWindow(url) {
  window.open(url,'popupWindow','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,width=800,height=800,screenX=150,screenY=150,top=15,left=15')
}
//--></script>
<table border="0" width="100%" cellspacing="2" cellpadding="2">
  <tr>
    <td width="100%" valign="top"><table border="0" width="100%" cellspacing="0" cellpadding="0">
     <tr>
     </tr>
     <!-- BEGIN LOWER SECTION -->
     <tr>
      <td><table width="100%" border="0" cellspacing="0" cellpadding="0" class="BorderedBoxWhite">
       <!-- BEGIN DELETE AND GENERATE FILE -->
       <tr>
        <td colspan="2"><table width="100%" border="0" cellspacing="0" cellpadding="0">
         <tr>
          <td align="right"><?php echo tep_draw_form('database_optimizer', FILENAME_DATABASE_OPTIMIZER, '', 'post') . tep_draw_hidden_field('action_run_optimizer', 'process'); ?></td>
           <tr>
            <td><table border="0" width="100%" border="0" cellspacing="0" cellpadding="2">
              <?php foreach ($optionsArray as $option) { ?>
                <tr>
                  <td><?php echo tep_draw_checkbox_field($option['post'], '', false); ?> </td>
                  <td class="smallText"><?php echo $option['option']; ?></td>
                  <td class="smallText"><?php echo $option['explain']; ?></td>
                </tr>
              <?php } ?>
            </table></td>
           </tr>
           <tr>
             <td><table border="0" width="40%" border="0" cellspacing="0" cellpadding="2">
               <tr>
                 <td align="center"><?php echo tep_image_submit('button_update.gif', IMAGE_UPDATE);?></td>
               </tr>
             </table></td>
           </tr>
          </form>
          </td>
         </tr>
        </table></td>
       </tr>
       <!-- END DELETE AND GENERATE FILE -->
       <!-- BEGIN SHOW THE RESULTS -->
       <?php if (tep_not_null($message)) { ?>
       <tr>
        <td><?php echo tep_draw_separator('pixel_trans.gif', '100%', '10'); ?></td>
       </tr>
       <tr>
         <td colspan="2"><table width="100%" border="0" cellspacing="0" cellpadding="0">
           <tr>
             <td class="smallText" style="padding-left:10px; padding-bottom:5px"><?php echo str_replace("\r\n", "<br>", $message); ?></td>
           </tr>
         </table></td>
       </tr>
       <?php } ?>
       <!-- END SHOW THE RESULTS -->
      </table></td>
     </tr>
     <!-- END LOWER SECTION -->
    </table></td>
  </tr>
</table>
<?php
  require(DIR_WS_INCLUDES . 'template_bottom.php');
  require(DIR_WS_INCLUDES . 'application_bottom.php');
?>