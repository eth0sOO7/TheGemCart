<?php
/*
  $Id: contrib_tracker.php,v 1.7.17 2009/09/05 15:57:07 stevedallas Exp $
  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com
  05 Sep 2009 GCH 1.7.17 Complete rewrite of RDF file handling.
                           No longer requires or creates a cache file
                         Complete rewrite of XML parsing - no longer uses rdf_class.php 
  28 Nov 2008 GCH 1.7.14 Several bug fixes in insert routine for correct processing of non-osCommerce support site contributions
                         date added can now be edited
                         clears sID on page change
  26 Nov 2008 lildog 1.7.13 When adding a new contrib date added and last official update were getting mixed up
                         changed a couple of variables so they are more obvious
  08 Nov 2008 GCH 1.7.12 Quick Add now searches for a support topic and inserts it into the database
                         Insert now adds support topic if user didn't provide one and one exists in the contribution description
                         Quick Add and Insert no longer add duplicate records
                         toggleDivBlock() now uses the code from osC 2.2RC2a
                         Extensive use of tep_get_all_get_params() to preserve parameters - no longer loses sort order on updates
                         Fixed two minor HTML errors that occurred with empty searches and an empty contrib_tracker table
                         Clicking anywhere on a row in the table of contributions will select it
                         Fixed the operation of the manual check button (manualcheckall worked; manualcheck didn't)
  08 Nov 2008 lildog 1.7.11 realigned buttons in insert contribution page
  07 Nov 2008 lildog 1.7.10 My sql needed quotes around 'LAST_CONFIG_CHECK' from version 1.7.8.
  07 Nov 2008 lildog 1.7.9  Fixed Insert so it works with contributions with apostrophes in their titles
  28 Oct 2008 GCH 1.7.8  Changed config update to use key LAST_CONFIG_CHECK instead of raw configuration_id, which is installation dependent
                         Rebuilt all tables to ensure correct HTML structure
                         Re-created missing Javascript function toggleDivBlock() to make "info" links work in editor
                         Modified logic to suppress search, quick add, and last update boxes in edit and preview modes
                         Escaped a ton of ampersands to "&amp;" for HTML 4.01 Transitional DTD conformance
                         (Note that some modes still generate non-conforming HTML due to minor bugs in osC functions tep_draw_form() and tep_draw_textarea_field() )
                         Simplified status icon display code
  Copyright (c) 2003 osCommerce
  Released under the GNU General Public License
_________________________________________________________________
Contribution Tracker MODULE for osC Admin
By Admin of www.silvermoon-jewelry.com
Based on:
        Admin_notes: Original Code By: Robert Hellemans of www.RuddlesMills.com
        RSS News for OSC
These are LIVE SHOPS - So please, no TEST accounts etc...
We will report you to your ISP if you abuse our websites!
#####
make a function to display month's english and vise versa.
####
*/
require('includes/application_top.php');
require(DIR_WS_LANGUAGES . $language . '/' . FILENAME_CONTRIB_TRACKER);
require(DIR_WS_FUNCTIONS . 'contrib_tracker.php');
$xmlURL='http://feedproxy.feedburner.com/osCommerce_Contributions';
$addonsURL='http://addons.oscommerce.com/';
$contribsURL='http://addons.oscommerce.com/info/';
$contrib_supportURL='http://forums.oscommerce.com/index.php?showtopic=';
$addonsRDFURL='http://www.oscommerce.com/oscommerce_contributions.rdf';
$format = '%Y-%m-%d %H:%M:%S';
//Function to parse the RDF feed
//Does not rely on PHP XML parser due to issues.
    function parse_xml($text) {
      $reg_exp = '/<(\w+)[^>]*>(.*?)<\/\\1>/s';
      preg_match_all($reg_exp, $text, $match);
      foreach ($match[1] as $key=>$val) {
        if ( preg_match($reg_exp, $match[2][$key]) ) {
            $array[$val][] = parse_xml($match[2][$key]);
        } else {
		    if ( preg_match('/<!\[CDATA\[(.*?)\]\]>/s',$match[2][$key], $string) ) {
			    $array[$val] = $string[1];
			} else {
                $array[$val] = $match[2][$key];
			}
        }
      }
      return $array;
    } 
  if (!function_exists("file_get_contents")) {
  //get contents of file into a string
  //For compatibility with PHP4 < 4.3.0
    function file_get_contents($f) {
      $h = @fopen($f, 'rb'); //rss cached file path
      if ($h) {
        $data = '';
        while (!feof($h)) {
          $d .= fread($h, 8192);
	    }
        fclose($h);
      } else {
        $d = $false;
      }
	  return $d;
	}
  }
//rss file path
// THIS GETS THE FEED AND PARSES IT
$data = @file_get_contents($xmlURL);
if (!$data && (extension_loaded('curl') == 1)) {
  $data = curl_get_osc_contents($xmlURL);
}
if ($data) {
  $response = parse_xml($data);
  $articlelist = $response['rss'][0]['channel'][0];
  foreach ($articlelist['item'] as $article ) {
    $thelink = $article['link'];
    $thetitle = $article['title'];
    $osc_rss_pubdate_raw = $article['pubDate'];
    $osc_rss_pubdate = strtotime($osc_rss_pubdate_raw);
    $osc_rss_pubdate = strftime ($format, $osc_rss_pubdate);
// add backslashes to characters that need escaping
    $thetitle=addslashes($thetitle);
// UPDATE THE CONTRIBUTIONS THAT ARE IN THE RSS FILE
    tep_db_query("UPDATE " . TABLE_CONTRIB_TRACKER . " SET status ='0', contr_last_modified = '" . $osc_rss_pubdate . "' where contrib_name = '" . $thetitle . "' and last_update < '" . $osc_rss_pubdate . "'");
  }
}
  switch ($HTTP_GET_VARS['action']) {
    case 'setflag':
      tep_set_contrib_query_status($HTTP_GET_VARS['id'], $HTTP_GET_VARS['flag'], $HTTP_GET_VARS['contr_last_modified']);
      tep_redirect(tep_href_link(FILENAME_CONTRIB_TRACKER, tep_get_all_get_params(array('flag', 'action', 'id', 'contr_last_modified'))));
      break;
    case 'updatecheck':
      $contrib_query = "update " . TABLE_CONFIGURATION . " set configuration_value = '" . $HTTP_POST_VARS['lastcheck'] . "', last_modified = now() where configuration_key = 'LAST_CONFIG_CHECK'";    
      if (tep_db_query($contrib_query)){
        $messageStack->add_session(MESSAGE_UPDATECHECK_SUCCESS, 'success');
      }else{
        $messageStack->add_session(MESSAGE_UPDATECHECK_ERROR, 'error');
      } 
      tep_redirect(tep_href_link(FILENAME_CONTRIB_TRACKER, (array('action'))));
      break;
    case 'insert':
      if ($HTTP_POST_VARS['today_date']){
        $date_updated =date("Y-m-d H:M:S");
      }else{
        $date_updated=strtotime($HTTP_POST_VARS['last_update']);
        $date_updated=strftime ($format, $date_updated);
      }
      if ($HTTP_POST_VARS['today_date2']){
        $date_added =date("Y-m-d H:M:S");
      }else{
        $date_added=strtotime($HTTP_POST_VARS['note_created']);
        $date_added=strftime ($format, $date_added);
      }
      $new_contrib_id=$HTTP_POST_VARS['contrib_id_new'];
      $contrib_name=stripslashes($HTTP_POST_VARS['contrib_name_new']);
      $contrib_link=old_to_new_url($HTTP_POST_VARS['contrib_link_new']);
      if ($contrib_link == '') {
        $contrib_link = $contribsURL . $new_contrib_id;
      }
      //check whether contrib is already in database
      if ($HTTP_POST_VARS['contrib_id_new'] !=='') {
        $contrib_raw = "select contrib_osc_id from " . TABLE_CONTRIB_TRACKER . " where contrib_osc_id = " . $HTTP_POST_VARS['contrib_id_new'];
        $contrib_query = tep_db_query($contrib_raw);
        $record_found = (tep_db_num_rows($contrib_query) !== 0);
      } else {
        $record_found = false;
      }
      if (!$record_found){
        //if the id is empty get it
        $new_contrib_id=get_contrib_id($contrib_link,$new_contrib_id);
        //get contribs info from it's URL
        if(!empty($new_contrib_id)){
          contrib_check($new_contrib_id);
        }
        //set flag to red if need be
        if (strtotime($date_updated) < strtotime($last_osc_update)){
          $status='0';
        } else {
          $status='1';
        }
        //Add support link if user didn't provide one and one exists in the contrib info
        if ($HTTP_POST_VARS['contrib_link_support'] !='') {
          $contrib_support_link = $HTTP_POST_VARS['contrib_link_support'];
        } elseif ($contrib_support_topic) {
          $contrib_support_link = $contrib_supportURL . $contrib_support_topic;
        } else {
          $contrib_support_link = '';
        }
        $contrib_query = "insert into " . TABLE_CONTRIB_TRACKER . " (contr_id, contrib_osc_id, contrib_name, contrib_link, contrib_support, config_comments, note_created, contr_last_modified, status, last_update, contrib_vers) values ('','" . $HTTP_POST_VARS['contrib_id_new'] . "','" . addslashes($contrib_name) . "','" . $contrib_link . "','" . $contrib_support_link . "','" . $HTTP_POST_VARS['config_comments'] . "', '" .  $date_added . "', '" .  $last_osc_update . "',  '" .  $status . "', '" .      $date_updated . "', '" . $HTTP_POST_VARS['contrib_vers'] . "' )";
        if ( tep_db_query($contrib_query) ){
          $messageStack->add_session(MESSAGE_INSERT_SUCCESS, 'success');
        } else {
          $messageStack->add_session(MESSAGE_INSERT_ERROR, 'error');
        }
      } else {
          $messageStack->add_session(MESSAGE_INSERT_DUPLICATE, 'error');
      }
      tep_redirect(tep_href_link(FILENAME_CONTRIB_TRACKER, tep_get_all_get_params(array('action'))));
      break;
    case 'update':
      if (($old_status!=='1' && $status=='1') || ($HTTP_POST_VARS['today_date'])){
        $last_update=date("Y-m-d H:M:S");
      }else{
         $last_update=$HTTP_POST_VARS['last_update'];      
      }
      //Get the creation date
      $note_created=$HTTP_POST_VARS['note_created'];
      //convert old links to new ones
      $link=old_to_new_url($HTTP_POST_VARS['contrib_link_new']);
      $new_contrib_id=$HTTP_POST_VARS['contrib_id_new'];
      $contrib_name=$HTTP_POST_VARS['contrib_name_new'];
      //if the id is empty get it
      $new_contrib_id=get_contrib_id($link,$new_contrib_id);
      //if the name is empty get it
      if (empty($contrib_name) && !empty($new_contrib_id)){
        contrib_check($new_contrib_id);
      }else{
        $contrib_name=$HTTP_POST_VARS['contrib_name_new'];
      }
      //tep_db_query("update " .TABLE_CONTRIB_TRACKER . " set contr_last_modified = now(), status =  '" . $HTTP_POST_VARS['status'] . "', contrib_osc_id =  '" . $new_contrib_id . "',contrib_name =  '" . $contrib_name . "', contrib_link =  '" . $HTTP_POST_VARS['contrib_link_new'] . "', config_comments = '" . $HTTP_POST_VARS['config_comments'] . "', last_update = '" .$last_update. "', contrib_vers= '" . $HTTP_POST_VARS['contrib_vers'] . "'  where contr_id = '" . $HTTP_POST_VARS['contr_id'] . "'");
      $contrib_query = "update " .TABLE_CONTRIB_TRACKER . " set contr_last_modified = now(), status =  '" . $HTTP_POST_VARS['status'] . "', contrib_osc_id =  '" . $new_contrib_id . "',contrib_name =  '" . $contrib_name . "', contrib_link =  '" . $link . "', contrib_support =  '" . $HTTP_POST_VARS['contrib_link_support'] . "', config_comments = '" . $HTTP_POST_VARS['config_comments'] . "', last_update = '" . $last_update . "', note_created = '" . $note_created . "', contrib_vers= '" . $HTTP_POST_VARS['contrib_vers'] . "'  where contr_id = '" . $HTTP_POST_VARS['contr_id'] . "'";
      if ( tep_db_query($contrib_query) ){
        $messageStack->add_session(MESSAGE_UPDATE_SUCCESS, 'success');
      }else{
        $messageStack->add_session(MESSAGE_UPDATE_SUCCESS, 'error');
      }
      tep_redirect(tep_href_link(FILENAME_CONTRIB_TRACKER, tep_get_all_get_params(array('action', 'sID')) . 'sID=' . $contr_id));
      break;
    case 'deleteconfirm':
      $contr_id = tep_db_prepare_input($HTTP_GET_VARS['sID']);
      // tep_db_query("delete from " . TABLE_CONTRIB_TRACKER. " where contr_id = '" . tep_db_input($contr_id) . "'");
      $contrib_query = "delete from " . TABLE_CONTRIB_TRACKER. " where contr_id = '" . tep_db_input($contr_id) . "'";
      if ( tep_db_query($contrib_query) ){
        $messageStack->add_session(MESSAGE_DELETE_SUCCESS, 'success');
      }else{
        $messageStack->add_session(MESSAGE_DELETE_ERROR, 'error');
      }
      tep_redirect(tep_href_link(FILENAME_CONTRIB_TRACKER, tep_get_all_get_params(array('action', 'sID'))));
      break;
    case 'manualcheck':
      contrib_check($HTTP_GET_VARS['oscID']);
      //if the date is newer then update the contrib database entry
      $update_query="UPDATE " . TABLE_CONTRIB_TRACKER . " SET status ='0', contr_last_modified = '" . $last_osc_update . "' WHERE contrib_osc_id = '" . $HTTP_GET_VARS['oscID'] . "' and last_update < '" . $last_osc_update . "'";
      if ( tep_db_query($update_query) ){
        $messageStack->add_session(MESSAGE_UPDATE_SUCCESS, 'success');
      }else{
        $messageStack->add_session(MESSAGE_UPDATE_ERROR, 'error');
      }
      tep_redirect(tep_href_link(FILENAME_CONTRIB_TRACKER, tep_get_all_get_params(array('action', 'oscID', 'contr_last_modified', 'lastupdate'))));
      break;
    case 'quick_insert':
      if (is_numeric($HTTP_POST_VARS['contrib_quick_insert'])){
        $date_updated =date("Y-m-d H:M:S");
        $date_added =date("Y-m-d H:M:S");
        $new_contrib_id=$HTTP_POST_VARS['contrib_quick_insert'];
        $new_contrib_id = substr($HTTP_POST_VARS['contrib_quick_insert'] , strrpos($HTTP_POST_VARS['contrib_link_new'] , '/') +1);
        //check whether contrib is already in database
        $contrib_raw = "select contrib_osc_id from " . TABLE_CONTRIB_TRACKER . " where contrib_osc_id = " . $HTTP_POST_VARS['contrib_quick_insert'];
        $contrib_query = tep_db_query($contrib_raw);
        if (tep_db_num_rows($contrib_query) == 0){
          //the get contrib info
          contrib_check($HTTP_POST_VARS['contrib_quick_insert']);
          $newvers='';
          //set flag to green
          $status='1';
          if ($contrib_support_topic) {
            $contrib_support_link = $contrib_supportURL . $contrib_support_topic;
          } else {
            $contrib_support_link = '';
          }
          $contrib_query = "insert into " . TABLE_CONTRIB_TRACKER . " (contr_id, contrib_osc_id, contrib_name, contrib_link, contrib_support, config_comments, note_created, contr_last_modified, status, last_update, contrib_vers) values ('','" . $HTTP_POST_VARS['contrib_quick_insert'] . "','" . addslashes($contrib_name) . "','" . $contribsURL . $HTTP_POST_VARS['contrib_quick_insert'] . "','" . $contrib_support_link . "','" . '' . "',  '" .  $date_added . "', '".$last_osc_update."', '".$status."', '" .      $date_updated . "', '" . $newvers . "' )";
          if ( tep_db_query($contrib_query) ){
            $messageStack->add_session(MESSAGE_INSERT_SUCCESS, 'success');
          } else {
            $messageStack->add_session(MESSAGE_INSERT_ERROR, 'error');
          }
        } else {
            $messageStack->add_session(MESSAGE_INSERT_DUPLICATE, 'error');
        }
        tep_redirect(tep_href_link(FILENAME_CONTRIB_TRACKER, tep_get_all_get_params(array('action'))));
      }
      break;
    case 'manualcheckall':
      //$admin_query_query_raw = "select contr_id, contrib_osc_id, contrib_name, contrib_link, contrib_support, status, note_created , contr_last_modified, last_update,config_comments, contrib_vers from " . TABLE_CONTRIB_TRACKER . " order by contrib_name ";
      $manualcheckall_raw = "select contr_id, contrib_osc_id, contrib_name, status, note_created , contr_last_modified, last_update from " . TABLE_CONTRIB_TRACKER . " order by contrib_name ";
      $manualcheckall_query = tep_db_query($manualcheckall_raw);
      if (tep_db_num_rows($manualcheckall_query) == 0){
        $messageStack->add_session(MESSAGE_MANUALALL_NONE_ERROR, 'error');
      }else{
        while ($admin_quer = tep_db_fetch_array($manualcheckall_query)) {
          $sInfo_array = array_merge($admin_quer);
          /*print_r($sInfo_array[contrib_osc_id]);
          echo '<br>';*/
          $contrib_osc_id=$sInfo_array[contrib_osc_id];
          contrib_check($contrib_osc_id);
          //if the date is newer then update the contrib database entry
          $update_query="UPDATE " . TABLE_CONTRIB_TRACKER . " SET status ='0', contr_last_modified = '" . $last_osc_update . "' WHERE contrib_osc_id = '" . $contrib_osc_id . "' and last_update < '" . $last_osc_update . "'";
          if ( !tep_db_query($update_query) ){
            //$messageStack->add_session(MESSAGE_MANUALALL_SUCCESS, 'success');
          //}else{
            $messageStack->add_session(MESSAGE_MANUALALL_ERROR.$sInfo_array[contrib_name], 'error');
          }
        }
      }
      tep_redirect(tep_href_link(FILENAME_CONTRIB_TRACKER, tep_get_all_get_params(array('action'))));
      break;
  }
  require(DIR_WS_INCLUDES . 'template_top.php');
?>
    <script language="javascript" type="text/javascript">
      function toggleDivBlock(id) {
        if (document.getElementById) {
          itm = document.getElementById(id);
        } else if (document.all){
          itm = document.all[id];
        } else if (document.layers){
          itm = document.layers[id];
        }
        if (itm) {
          if (itm.style.display != "none") {
            itm.style.display = "none";
          } else {
            itm.style.display = "block";
          }
        }
      } 
    </script>
<?php
// set sub title
      if ( $HTTP_GET_VARS['action'] == 'readonly') $HEADING_SUB_TITLE = HEADING_SUB_TITLE_READONLY;
      if ( $HTTP_GET_VARS['action'] == 'delete') $HEADING_SUB_TITLE = HEADING_SUB_TITLE_DELETE;
      if ( $HTTP_GET_VARS['action'] == 'update') $HEADING_SUB_TITLE = HEADING_SUB_TITLE_EDIT;
      if ( $HTTP_GET_VARS['action'] == 'edit') $HEADING_SUB_TITLE = HEADING_SUB_TITLE_EDIT;
      if ( $HTTP_GET_VARS['action'] == 'new') $HEADING_SUB_TITLE = HEADING_SUB_TITLE_INSERT;
      if ( $HTTP_GET_VARS['action'] == 'setflag') $HEADING_SUB_TITLE = HEADING_SUB_TITLE_SETFLAG;
      if ( $HTTP_GET_VARS['action'] == '') $HEADING_SUB_TITLE = HEADING_SUB_TITLE;
if ( ($HTTP_GET_VARS['action'] == 'new') || ($HTTP_GET_VARS['action'] == 'edit') ) {
?>
    <link rel="stylesheet" type="text/css">
<?php
  }
?>
  </head>
  <body bgcolor="#FFFFFF" onload="SetFocus();">
    <div id="spiffycalendar" class="text"></div>
<!-- body //-->
    <table border="0" width="100%" cellspacing="2" cellpadding="2">
      <tr>
<!-- body_text //-->
        <td width="100%" valign="top">
          <table border="0" width="100%" cellspacing="0" cellpadding="0">
            <tr>
              <td class="pageHeading"><?php echo HEADING_TITLE; ?>
                <?php echo '<a href="'.$addonsURL.'" target="_blank">' . tep_image(DIR_WS_IMAGES . 'html_badge.gif', HEADING_CONTRIB_HTML_SUPPORT_SITE, '80', '15') . '</a>&nbsp;&nbsp; <a href="'. $addonsURL .'" target="_blank">' . tep_image(DIR_WS_IMAGES . 'rss_badge.gif', HEADING_CONTRIB_RSS_SUPPORT_SITE, '80', '15') . '</a>'; ?>&nbsp;&nbsp;
                <br><font class="smallText"><?php echo $HEADING_SUB_TITLE; ?></font>
              </td>
              <td class="pageHeading" align="right"><?php echo tep_draw_separator('pixel_trans.gif', 10, 1); ?></td>
<?php 
  if ($HTTP_GET_VARS['action'] != 'new' && $HTTP_GET_VARS['action'] != 'edit' && $HTTP_GET_VARS['action'] != 'readonly') {
    if (htmlspecialchars(StripSlashes(@$HTTP_GET_VARS["search"])) == ''){
      $searchquery = ''; 
    } else { 
      $searchquery = htmlspecialchars(StripSlashes(@$HTTP_GET_VARS["search"])) ;
    }
?>
              <td align="right">
                <table border="0" width="100%" cellspacing="0" cellpadding="1">
                  <tr> 
                    <td class="smallText" align="right"> 
                      <?php echo tep_draw_form('search', FILENAME_CONTRIB_TRACKER, tep_get_all_get_params(array('action')), 'get');
                            echo HEADING_TITLE_CONTRIBSEARCH . ' ' . tep_draw_input_field('search', $searchquery, "onFocus=\"if (this.value == 'enter search query') { this.value='' }\""); ?>
                      </form>
                    </td>
                  </tr>
                  <tr>
                    <td class="smallText" align="right">
                      <?php echo tep_draw_form('quick_insert', FILENAME_CONTRIB_TRACKER, 'action=quick_insert', 'post');
                            echo TEXT_QUICKOSC_ID .' '. TEXT_ID_QUICK_NEW . ' ' . tep_draw_input_field('contrib_quick_insert', '', "onFocus=\"if (this.value == 'enter contrib ID') { this.value='' }\""); ?>
                      </form>
                    </td>
                  </tr>
                  <tr>
    <?php if ($HTTP_GET_VARS['action']== 'editlastcheck') { ?>
 <!--  SHOW THE TITLE AND A FIELD TO ENTER A NEW DATE -->
                    <td class="smallText" align="right">
                      <?php echo tep_draw_form('lastcheck', FILENAME_CONTRIB_TRACKER,'action=updatecheck&amp;id=' . $admin_quer['contr_id'] . '&amp;page=' . $HTTP_GET_VARS['page'] .  '&amp;sID=' . $HTTP_GET_VARS['sID'], 'post');
                            echo HEADING_LAST_CHECK . ' ' . tep_draw_input_field('lastcheck', LAST_CONFIG_CHECK); ?>
                      </form>
                    </td>
    <?php } else { ?>
<!-- // JUST SHOW THE TITLE AND DATE FOR LAST MANUAL UPDATE AS A LINK -->
                    <td class="smallText" align="right"> 
                      <?php echo ' <a href="' . tep_href_link(FILENAME_CONTRIB_TRACKER, tep_get_all_get_params(array('action', 'id')) . 'action=editlastcheck&amp;id=' . $admin_quer['contr_id'], 'NONSSL') . '">'.HEADING_LAST_CHECK.' '.LAST_CONFIG_CHECK .'</a>'; ?>
                    </td>
    <?php } ?>
                  </tr>
                </table>
              </td>
<?php 
}
?>            
            </tr>
<?php
  if ( ($HTTP_GET_VARS['action'] == 'new') || ($HTTP_GET_VARS['action'] == 'edit') ) {
    if ($HTTP_GET_VARS['action'] == 'new'){
      $form_action = 'insert';
    }else if ($HTTP_GET_VARS['action'] == 'edit'){
      $form_action = 'update';
    }
// UPDATE A CONTRIBUTION ENTRY
    if ( ($HTTP_GET_VARS['action'] == 'edit') && ($HTTP_GET_VARS['sID']) ) {
      $product_query = tep_db_query("select contr_id, contrib_osc_id, contrib_name, contrib_link, contrib_support, status, config_comments, last_update, note_created,contrib_vers from " . TABLE_CONTRIB_TRACKER . " where contr_id = '" . $HTTP_GET_VARS['sID'] . "'");
      $product = tep_db_fetch_array($product_query);
      $sInfo = new objectInfo($product);
    } else {
      $sInfo = new objectInfo(array());
      $contr_array = array();
    }
?>
            <tr>
              <td>
                <form name="new_contr" <?php echo 'action="' . tep_href_link(FILENAME_CONTRIB_TRACKER, tep_get_all_get_params(array('action', 'info', 'sID')) . 'action=' . $form_action, 'NONSSL') . '"'; ?> method="post"><?php if ($form_action == 'update') echo tep_draw_hidden_field('contr_id', $HTTP_GET_VARS['sID']) ; ?>
                  <br>
                  <table border="0" cellspacing="0" cellpadding="2">
          <?php if ($HTTP_GET_VARS['action'] == 'new'){ ?>
                    <tr class="dataTableRow">
                      <td class="dataTableContent"><?php echo TEXT_OSC_ID; ?></td>
                      <td class="dataTableContent"><?php echo tep_draw_input_field('contrib_id_new', $sInfo-> contrib_osc_id, 'size=10 maxlength=10').' '. TEXT_ID_NOTE_NEW; ?></td>
                    </tr>
          <?php }else if ($HTTP_GET_VARS['action'] == 'edit'){ ?>        
                    <tr class="dataTableRow">
                      <td class="dataTableContent"><?php echo TEXT_OSC_ID; ?> <?php echo tep_draw_hidden_field('contrib_id_new', $sInfo-> contrib_osc_id);?></td>
                      <td class="dataTableContent"><?php echo $sInfo-> contrib_osc_id; ?></td>
                    </tr>
          <?php } ?>
                    <tr class="dataTableRow">
                      <td class="dataTableContent"><?php echo TEXT_NAME_VERSION; ?></td>
                      <td class="dataTableContent"><?php echo tep_draw_input_field('contrib_name_new', $sInfo-> contrib_name, 'size=50 maxlength=255').' '. TEXT_NAME_NOTE_NEW; ?></td>
                    </tr>
                    <tr class="dataTableRow">
                      <td class="dataTableContent"><?php echo TEXT_INFO_HTML; ?></td>
                      <td class="dataTableContent"><?php echo tep_draw_input_field('contrib_link_new', $sInfo-> contrib_link, 'size=50 maxlength=255').' '.TEXT_OSC_URL; ?></td>
                    </tr>
                    <tr class="dataTableRow">
                      <td class="dataTableContent"><?php echo TEXT_INFO_SUPPORT; ?></td>
                      <td class="dataTableContent"><?php echo tep_draw_input_field('contrib_link_support', $sInfo-> contrib_support, 'size=50 maxlength=255').' '.TEXT_OSC_SUPPORT; ?></td>
                    </tr>
          <!-- // insert version number field -->
                    <tr class="dataTableRow">
                      <td class="dataTableContent"><?php echo TEXT_VERSION_NUMBER; ?>&nbsp;</td>
                      <td class="dataTableContent"><?php echo tep_draw_input_field('contrib_vers', $sInfo->contrib_vers, 'size=50 maxlength=30').' '. TEXT_VERSION_NOTE_NEW; ?></td>
                    </tr>
                    <tr class="dataTableRow">
                      <td class="dataTableContent"><?php echo TEXT_INFO_TO_REMEMBER; ?>&nbsp;</td>
                      <td class="dataTableContent"><?php echo tep_draw_input_field('last_update',$sInfo->last_update, 'size=50 maxlength=30'). '  '. tep_draw_checkbox_field('today_date', $today_date,'',''). ' '. TEXT_TODAY_DATE.' '. TEXT_INT_DATE_NEW; ?></td>
                    </tr>
                    <tr class="dataTableRow">
                      <td class="dataTableContent"><?php echo TEXT_INFO_DATE_ADDED; ?>&nbsp;</td>
                      <td class="dataTableContent"><?php echo tep_draw_input_field('note_created',$sInfo->note_created, 'size=50 maxlength=30'). '  '. tep_draw_checkbox_field('today_date2', $today_date,'',''). ' '. TEXT_TODAY_DATE.' '. TEXT_ADD_DATE_NEW; ?></td>
                    </tr>
                    <tr class="dataTableRow">
                      <td valign="top" class="dataTableContent"><?php echo TEXT_CONFIG_COMMENTS; ?>&nbsp;</TD>
                      <td class="dataTableContent"><?php echo tep_draw_textarea_field('config_comments', 'soft', '70', '15', ($sInfo->config_comments)) ; ?></td>
                    </tr>
<?php
if ( $HTTP_GET_VARS['action'] == 'edit') {
?>                                        
                    <tr class="dataTableRow">
                      <td class="dataTableContent"><?php echo TEXT_CONFIG_STATUS; ?>&nbsp;</td>
                      <td class="dataTableContent"><?php echo tep_draw_input_field('status', $sInfo->status, 'size=2 maxlength=1'); ?> &nbsp;&nbsp;&nbsp;
                       0 = <?php echo tep_image(DIR_WS_IMAGES . 'icon_status_red.gif', TEXT_NEW_UPDATE_EXISTS , 10, 10); ?>&nbsp;&nbsp;<?php echo TEXT_NEW_UPDATE_EXISTS; ?>&nbsp;&nbsp;&nbsp;
                       1 = <?php echo tep_image(DIR_WS_IMAGES . 'icon_status_green.gif', TEXT_NO_NEW_UPDATE , 10, 10); ?>&nbsp;&nbsp;<?php echo TEXT_NO_NEW_UPDATE; ?>&nbsp;&nbsp;&nbsp;
                       2 = <?php echo TEXT_NO_STATUS; ?>&nbsp;&nbsp;&nbsp;
                      <td><?php echo tep_draw_hidden_field('old_status', $sInfo->status);?></td>
                    </tr>
<?php
}
?>
<!--                  </table>
                  <table border="0" width="100%" cellspacing="0" cellpadding="2"> -->
                    <tr>
                      <td class="main" colspan=2 align="right" valign="top"><br>
                      <?php echo (($form_action == 'insert') ? tep_draw_button(IMAGE_INSERT, 'plus', null, 'primary')   : tep_draw_button(IMAGE_UPDATE, 'pencil', null, 'primary')) .
                      '&nbsp;&nbsp;&nbsp;' . tep_draw_button(IMAGE_CANCEL, 'close', tep_href_link(FILENAME_CONTRIB_TRACKER, tep_get_all_get_params(array('action')))) .
                      '&nbsp;&nbsp;&nbsp;' . tep_draw_button(IMAGE_RESET, 'refresh', tep_href_link(FILENAME_CONTRIB_TRACKER, tep_get_all_get_params())); ?>
                       </td>
                  </table>
                </form>
              </td>
            </tr>
<?php
  } elseif ($HTTP_GET_VARS['action'] != 'readonly') {
?>
            <tr>
              <td colspan=3>
                <table border="0" width="100%" cellspacing="0" cellpadding="0">
                  <tr>
<!-- TABLE HEADINGS AND SORT ICONS-->
                    <td valign="top">
                      <table border="0" width="100%" cellspacing="0" cellpadding="2">
                        <tr class="dataTableHeadingRow">
                          <td class="dataTableHeadingContent">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="<?php echo "$PHP_SELF?sort=2a" . "&amp;page=" . $HTTP_GET_VARS['page'] . "&amp;sID=" . $HTTP_GET_VARS['sID']; ?>"><?php echo tep_image(DIR_WS_IMAGES . 'icon_up.gif', IMAGE_BUTTON_UPSORT); ?></a><a href="<?php echo "$PHP_SELF?sort=2d" . "&amp;page=" . $HTTP_GET_VARS['page'] . "&amp;sID=" . $HTTP_GET_VARS['sID']; ?>"><?php echo tep_image(DIR_WS_IMAGES . 'icon_down.gif', IMAGE_BUTTON_DOWNSORT); ?></a><br><?php echo TABLE_HEADING_NAME; ?></td>
                          <td class="dataTableHeadingContent" align="center"><br><?php echo TABLE_HEADING_VERSION; ?>&nbsp;</td><td class="dataTableHeadingContent" align="center"><a href="<?php echo "$PHP_SELF?sort=4a" . "&amp;page=" . $HTTP_GET_VARS['page'] . "&amp;sID=" . $HTTP_GET_VARS['sID']; ?>"><?php echo tep_image(DIR_WS_IMAGES . 'icon_up.gif', IMAGE_BUTTON_UPSORT); ?></a><a href="<?php echo "$PHP_SELF?sort=4d" . "&amp;page=" . $HTTP_GET_VARS['page'] . "&amp;sID=" . $HTTP_GET_VARS['sID']; ?>"><?php echo tep_image(DIR_WS_IMAGES . 'icon_down.gif', IMAGE_BUTTON_DOWNSORT); ?></a>&nbsp;&nbsp;<br><?php echo TABLE_HEADING_STATUS; ?></td>
                          <td class="dataTableHeadingContent" align="right"><br><?php echo TABLE_HEADING_ACTION; ?>&nbsp;</td>
                        </tr>
<?php
          switch ($sort) {
              case "2a":
               $order_it_by = "contrib_name, status ";
               break;
              case "2d":
               $order_it_by = "contrib_name DESC, status ";
               break;
              case "4a":
               $order_it_by = "status, contrib_name";
               break;
              case "4d":
               $order_it_by = "status DESC, contrib_name";
               break;
              case "5a":
               $order_it_by = "last_update, contrib_name";
               break;
              case "5d":
               $order_it_by = "last_update DESC, contrib_name";
               break;
              default:
               $order_it_by = "status, contrib_name";
                  }
// IF THIS IS A SEARCH GET THE SEARCH RESULTS FROM THE DB
    if ($HTTP_GET_VARS['search']) {
                    //contrib_support->'" . $HTTP_POST_VARS['contrib_link_support'] . "',
      $admin_query_query_raw = "select contr_id, contrib_osc_id, contrib_name, contrib_link, contrib_support, status, note_created , contr_last_modified, last_update,config_comments, contrib_vers from " . TABLE_CONTRIB_TRACKER . " where contrib_name like '%" . $HTTP_GET_VARS['search'] . "%' order by " . $order_it_by . " ";
      $admin_query_split = new splitPageResults($HTTP_GET_VARS['page'], MAX_DISPLAY_SEARCH_RESULTS, $admin_query_query_raw, $admin_query_query_numrows);
      $admin_query_query = tep_db_query($admin_query_query_raw);            
      if (tep_db_num_rows($admin_query_query) == 0) echo '<tr><td  class="dataTableContent" align="left">' . TEXT_NO_DATA . "</td></tr>\n";
    } else {
// IF THIS IS NOT A SEARCH SO GET ALL THE DATABASE ENTRIES
      $admin_query_query_raw = "select contr_id, contrib_osc_id, contrib_name, contrib_link, contrib_support, status, note_created , contr_last_modified, last_update,config_comments, contrib_vers from " . TABLE_CONTRIB_TRACKER . " order by " . $order_it_by . " ";
      $admin_query_split = new splitPageResults($HTTP_GET_VARS['page'], MAX_DISPLAY_SEARCH_RESULTS, $admin_query_query_raw, $admin_query_query_numrows);
      $admin_query_query = tep_db_query($admin_query_query_raw);
      if (tep_db_num_rows($admin_query_query) == 0) echo '<tr><td  class="dataTableContent" align="right">' . TEXT_EMPTY_DATABASE . "</td></tr>\n";
    }
    while ($admin_quer = tep_db_fetch_array($admin_query_query)) {
      if ( ((!$HTTP_GET_VARS['sID']) || ($HTTP_GET_VARS['sID'] == $admin_quer['contr_id'])) && (!$sInfo) ) {
        $sInfo_array = array_merge($admin_quer);
        $sInfo = new objectInfo($sInfo_array);
      }
 if ($HTTP_GET_VARS['search'] == '') {
      if ( (is_object($sInfo)) && ($admin_quer['contr_id'] == $sInfo->contr_id)) {
        echo ' <tr id="defaultSelected" class="dataTableRowSelected" onmouseover="rowOverEffect(this)" onmouseout="rowOutEffect(this)" onclick="document.location.href=\'' . tep_href_link(FILENAME_CONTRIB_TRACKER, tep_get_all_get_params(array('sID')) . 'sID=' . $admin_quer['contr_id']) . '\'">' . "\n";
      } else {
        echo ' <tr class="dataTableRow" onmouseover="rowOverEffect(this)" onmouseout="rowOutEffect(this)" onclick="document.location.href=\'' . tep_href_link(FILENAME_CONTRIB_TRACKER, tep_get_all_get_params(array('sID')) . 'sID=' . $admin_quer['contr_id']) . '\'">' . "\n";
      }
   } else {
    $searchresult_query_query_raw = "select contr_id from " . TABLE_CONTRIB_TRACKER . " order by " . $order_it_by . " ";
    $searchresult_query_query = tep_db_query($searchresult_query_query_raw);
    $searchresult_page= round($searchresult_query_query_numrows / MAX_DISPLAY_SEARCH_RESULTS)-1;
// INSERT CONTRIB NAMES INTO PAGE
      if ( (is_object($sInfo)) && ($admin_quer['contr_id'] == $sInfo->contr_id)) {
        echo ' <tr id="defaultSelected" class="dataTableRowSelected" onmouseover="rowOverEffect(this)" onmouseout="rowOutEffect(this)" onclick="document.location.href=\'' . tep_href_link(FILENAME_CONTRIB_TRACKER, tep_get_all_get_params(array('sID')) . 'sID=' . $admin_quer['contr_id']) . '\'">' . "\n";
      } else {
        echo ' <tr class="dataTableRow" onmouseover="rowOverEffect(this)" onmouseout="rowOutEffect(this)" onclick="document.location.href=\'' . tep_href_link(FILENAME_CONTRIB_TRACKER, tep_get_all_get_params(array('sID')) . 'sID=' . $admin_quer['contr_id']) . '\'">' . "\n";
      }
   }
    ?>
                          <td class="dataTableContent">
      <?php
         if ($admin_quer['contrib_link']){
           echo '<a target="_blank" href="' . $admin_quer['contrib_link'] . '" name="' . $admin_quer['contrib_name'] . '">' . $admin_quer['contrib_name'].'</a>';
         }else{
           echo $admin_quer['contrib_name'];
         }
      ?>
                          </td>
                          <td class="dataTableContent" align="center"><?php echo $admin_quer['contrib_vers'];?></td>
                          <td class="dataTableContent" align="center">
<?php
// SHOW THE STATUS ICONS
// contr_last_modified
      if ($admin_quer['status'] == '0') {
        echo tep_image(DIR_WS_IMAGES . 'icon_status_red.gif', TEXT_NEW_UPDATE_EXISTS, 10, 10) . '&nbsp;';
      } else { 
        echo '<a href="' . tep_href_link(FILENAME_CONTRIB_TRACKER, tep_get_all_get_params(array('action')) . 'action=setflag&amp;flag=0&amp;id=' . $admin_quer['contr_id'] . '&amp;contr_last_modified=' . $admin_quer['contr_last_modified'], 'NONSSL') . '">' . tep_image(DIR_WS_IMAGES . 'icon_status_red_light.gif', TEXT_SET_NEW_UPDATE_EXISTS, 10, 10) . '</a>&nbsp;'; 
      }
      if ($admin_quer['status'] == '1') {
        echo tep_image(DIR_WS_IMAGES . 'icon_status_green.gif', TEXT_NO_NEW_UPDATE, 10, 10);
      } else {
        echo '<a href="' . tep_href_link(FILENAME_CONTRIB_TRACKER, tep_get_all_get_params(array('action')) . 'action=setflag&amp;flag=1&amp;id=' . $admin_quer['contr_id'] . '&amp;contr_last_modified=' . $admin_quer['contr_last_modified'] , 'NONSSL') . '">' . tep_image(DIR_WS_IMAGES . 'icon_status_green_light.gif', TEXT_SET_NO_NEW_UPDATE, 10, 10) . '</a>';
      }
?>
                          </td>
                          <td class="dataTableContent" align="right">
<?php 
// INSERT THE ACTION ICONS
	  if ($admin_quer['contrib_support']) {
		echo '<a target="_blank" href="' .  $admin_quer['contrib_support'] . '">' .tep_image(DIR_WS_IMAGES . 'icon_help.gif', TEXT_OSC_SUPPORT_THREAD) . '</a>&nbsp;&nbsp;'; 
	  }
	  if ($admin_quer['contrib_osc_id']){
		echo '<a href="' . tep_href_link(FILENAME_CONTRIB_TRACKER, tep_get_all_get_params(array('action')) . 'action=manualcheck&amp;oscID=' . $admin_quer['contrib_osc_id'].'&amp;sID=' . $admin_quer['contr_id']) . '">' .tep_image(DIR_WS_IMAGES . 'icon_manual_check.jpg', TEXT_MANUAL_CHECK) . '</a>&nbsp;&nbsp;'; 
	  }
	  if (htmlspecialchars(StripSlashes(@$HTTP_GET_VARS["search"])) == '') {
		$reference = 'page';
	  } else {
		$reference = 'search';
	  }
	  if ( (is_object($sInfo)) && ($admin_quer['contr_id'] == $sInfo->contr_id) ) {
		echo tep_image(DIR_WS_IMAGES . 'icon_arrow_right.gif', '');
	  } else {
		echo '<a href="' . tep_href_link(FILENAME_CONTRIB_TRACKER, tep_get_all_get_params(array('action', 'sID')) . 'sID=' . $admin_quer['contr_id']) . '">' .tep_image(DIR_WS_IMAGES . 'icon_info.gif', TEXT_INFO) . '</a>'; 
	  }
?>
                          </td>
                        </tr>
<?php
    }
?>
                        <tr>
                          <td colspan="5">
                            <table border="0" width="100%" cellpadding="0"cellspacing="2">
                              <tr>
                                <td class="smallText" valign="top"><?php echo $admin_query_split->display_count($admin_query_query_numrows, MAX_DISPLAY_SEARCH_RESULTS, $HTTP_GET_VARS['page'], TEXT_DISPLAY_NUMBER_OF_RECORDS); ?></td>
                                <td class="smallText" align="right"><?php echo $admin_query_split->display_links($admin_query_query_numrows, MAX_DISPLAY_SEARCH_RESULTS, MAX_DISPLAY_PAGE_LINKS, $HTTP_GET_VARS['page'], 'sort=' . $HTTP_GET_VARS['sort']); ?></td>
                              </tr>
                   <?php
                      if (!$HTTP_GET_VARS['action']) {
                    ?>
                              <tr> 
                                <td class="smallText" colspan="2" align="right">
                                  <?php echo tep_draw_button(IMAGE_CHECKALL, 'notice', tep_href_link(FILENAME_CONTRIB_TRACKER, tep_get_all_get_params(array('action')) . 'action=manualcheckall')); ?>
                                  <?php echo tep_draw_button(IMAGE_INSERT, 'plus', tep_href_link(FILENAME_CONTRIB_TRACKER, '&action=new')); ?>
                                </td>
                              </tr>
<!-- // INSERT THE HELP NOTES -->
                              <tr> 
                                <td class="smallText" colspan="2" align="left">
                                  <?php echo '<B>'. TEXT_HELP_NOTES_HEADER . '</B><br><ul>' . TEXT_HELP_NOTES . '</ul><br><BR>'; ?>
                                </td>
                              </tr>
                              <tr>
<!-- // INSERT NEWEST CONTRIBS FROM RSS -->
                                <td class="smallText" colspan="2" align="left"> <B><?php echo TEXT_CONTRIB_HEADER; ?></B> <br>
<?php
if (is_array($articlelist)) {
  echo "<ol>\n";
  foreach ($articlelist['item'] as $article ) {
    $thelink = $article['link'];
    $thetitle = $article['title'];
    echo "<li><a href=\"" . $thelink . "\" target=\"_blank\">" . $thetitle . "</a></li>\n";
  }
  echo "</ol>\n";
} else {
  echo "ERROR: Could not open RDF feed\n";
} 
?>
                                </td>
                              </tr>
<?php
  } 
?>  
                            </table>
                          </td>
                        </tr>
                      </table>
                    </td>
<?php
  $heading = array();
  $contents = array();
// RIGHT COLUMN STUFF
  switch ($HTTP_GET_VARS['action']) {
    case 'delete':
      $heading[] = array('text' => '<center><b>' . TEXT_INFO_HEADING_DELETE . '</b></center>');
      $contents = array('form' => tep_draw_form('install_contr_del', FILENAME_CONTRIB_TRACKER, tep_get_all_get_params(array('action')) . 'action=deleteconfirm'));
      $contents[] = array('text' => TEXT_INFO_DELETE_INTRO);
      $contents[] = array('text' => '<br><b>' . $sInfo-> contrib_name . '</b>');
      $contents[] = array('align' => 'center', 'text' => '<br>' . tep_draw_button(IMAGE_DELETE, 'trash', null, 'primary') .
      '&nbsp;' . tep_draw_button(IMAGE_CANCEL, 'close', tep_href_link(FILENAME_CONTRIB_TRACKER, tep_get_all_get_params(array('action')) . 'sID=' . $sInfo->contr_id)));
      break;
    default:
      if (is_object($sInfo)) {
        $heading[] = array('text' => '<center><b>' . $sInfo->contrib_name . '</b></center>');
        $contents[] = array('align' => 'center', 'text' => '<b>'.TEXT_VERSION_NUMBER .'</b> '.$sInfo-> contrib_vers);
        $contents[] = array('text' => '<b>' . TEXT_INFO_TO_REMEMBER . '</b><BR> ' . $sInfo->last_update);
        $contents[] = array('text' => '<br> <b>' . TEXT_INFO_DATE_ADDED . '</b><BR> ' . $sInfo->note_created);
        $contents[] = array('text' => '<b>' . TEXT_INFO_LAST_MODIFIED . '</b><BR> ' . $sInfo->contr_last_modified . '<BR><BR>');
        $contents[] = array('text' =>  '<b>' .TEXT_CONFIG_COMMENTS .'</b> '. $sInfo->config_comments);
        $contents[] = array('align' => 'center', 'text' => tep_draw_button(IMAGE_EDIT, 'pencil', tep_href_link(FILENAME_CONTRIB_TRACKER, tep_get_all_get_params(array('action', 'sID')) . 'sID=' . $sInfo->contr_id .
        '&amp;action=edit')) .
        tep_draw_button(IMAGE_DELETE, 'trash', tep_href_link(FILENAME_CONTRIB_TRACKER, tep_get_all_get_params(array('action', 'sID')) . 'sID=' . $sInfo->contr_id . '&amp;action=delete')) .
        '<br><br>' . tep_draw_button(IMAGE_PREVIEW, 'preview', tep_href_link(FILENAME_CONTRIB_TRACKER, tep_get_all_get_params(array('action', 'sID')) . 'sID=' . $sInfo->contr_id . '&amp;action=readonly')));
      }
      break;
  }
  if ( (tep_not_null($heading)) && (tep_not_null($contents)) ) {
    echo '            <td width="25%" valign="top">' . "\n";
    $box = new box;
    echo $box->infoBox($heading, $contents);
    echo '            </td>' . "\n";
  } ?>
                  </tr>
                </table>
              </td>
            </tr>
<?php } elseif ($HTTP_GET_VARS['action'] == 'readonly') {
// BOF READONLY/PREVIEW
      $product_query = tep_db_query("select contr_id, contrib_osc_id, contrib_name,contrib_link, status, config_comments, note_created, contr_last_modified, last_update from " . TABLE_CONTRIB_TRACKER . " where contr_id = '" . $HTTP_GET_VARS['sID'] . "'");
      $product = tep_db_fetch_array($product_query);
      $sInfo = new objectInfo($product);
      if ($sInfo->status == '0') $status_desc = IMAGE_ICON_STATUS_GREEN;
      if ($sInfo->status == '1') $status_desc = IMAGE_ICON_STATUS_RED;      
      if ($sInfo->status == '2') $status_desc = IMAGE_ICON_STATUS_NONE;
?>
            <tr>
              <td colspan=3>
                <br>
                <table border="0" cellspacing="0" cellpadding="2" class="formArea" align="center">
                  <tr class="dataTableRow">
                    <td class="dataTableContent" NOWRAP><b><?php echo TEXT_OSC_ID; ?>&nbsp;</b></td>
                    <td class="formAreaTitle"><b><font color=blue><?php echo $sInfo-> contrib_osc_id; ?></font></b></td>
                  </tr>
                  <tr class="dataTableRow">
                    <td class="dataTableContent" NOWRAP><b><?php echo TEXT_NAME_VERSION; ?>&nbsp;</b></td>
                    <td class="formAreaTitle"><b><font color=blue><?php echo $sInfo-> contrib_name; ?></font></b></td>
                  </tr>
                  <tr class="dataTableRow">
                    <td class="dataTableContent" NOWRAP><b><?php echo TEXT_INFO_SUPPORT; ?>&nbsp;</b></td>
                    <td class="formAreaTitle"><b><font color=blue><?php echo $sInfo->contrib_support; ?></font></b></td>
                  </tr>
                  <tr class="dataTableRowOver">
                    <td VALIGN="top" class="dataTableContent" NOWRAP><b><?php echo TEXT_CONFIG_COMMENTS; ?>&nbsp;</b></td>
                    <td class="dataTableContent"><?php echo nl2br($sInfo->config_comments); ?></td>
                  </tr>
                  <tr class="dataTableRowOver">
                    <td class="dataTableContent" NOWRAP><b><?php echo TEXT_INFO_TO_REMEMBER; ?>&nbsp;</b></td>
                    <td class="dataTableContent"><?php echo $sInfo->last_update; ?></td>
                  </tr>
                  <tr class="dataTableRow">
                    <td class="dataTableContent" NOWRAP><b><?php echo TEXT_INFO_DATE_ADDED; ?>&nbsp;</b></td>
                    <td class="dataTableContent"><?php echo $sInfo->note_created; ?></td>
                  </tr>                    
                  <tr class="dataTableRowOver">
                    <td class="dataTableContent" NOWRAP><b><?php echo TEXT_INFO_LAST_MODIFIED; ?>&nbsp;</b></td>
                    <td class="dataTableContent"><?php if ($sInfo->contr_last_modified != '0000-00-00 00:00:00') echo $sInfo->contr_last_modified; ?></td>
                  </tr>                  
                  <tr class="dataTableRow">
                    <td class="dataTableContent" NOWRAP><b><?php echo TEXT_INFO_STATUS; ?>&nbsp;</b></td>
                    <td class="dataTableContent"><?php echo $sInfo->status . ':&nbsp;' . $status_desc; ?></td>
                  </tr>
                </table>
              </td>
            </tr>
            <tr>
              <td colspan=3 align="center" class="main">
                <br>
                <?php echo tep_draw_button(IMAGE_BACK, 'triangle-1-w', tep_href_link(FILENAME_CONTRIB_TRACKER, tep_get_all_get_params(array('action', 'sID')) . 'sID=' . $sInfo->contr_id, 'NONSSL')); ?>
              </td>
            </tr>      
<?php          
}
 // EOF readonly         
?>
          </table>
        </td>
<!-- body_text_eof //-->
      </tr>
    </table>
<!-- body_eof //-->
<?php
  require(DIR_WS_INCLUDES . 'template_bottom.php');
  require(DIR_WS_INCLUDES . 'application_bottom.php');
?>