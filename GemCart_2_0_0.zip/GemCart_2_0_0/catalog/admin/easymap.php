<?php
/* 
  $Id$ 
  The Gem Cart, the Diamond of E-Commerce shopping cart Solutions 
  TheGemCart, GemCart and The Gem Cart are registered service marks of GemCart Inc. 2012. 
  All rights reserved. 
  http://www.thegemcart.com 
  Copyright 2012 Gem Cart 
  Copyright (c) 2010 osCommerce (portions) 
  Released under the GNU General Public License 
  Version 2.0 2012-05-01 0eth0s & JoDaNo
*/ 
  require('includes/application_top.php');
  require(DIR_WS_FUNCTIONS . FILENAME_EASYMAP);
  $spacer = 5; //add a space between explanation
  /********************** BEGIN VERSION CHECKER *********************/
  if (file_exists(DIR_WS_FUNCTIONS . 'version_checker.php'))  {
      require(DIR_WS_LANGUAGES . $language . '/version_checker.php');
      require(DIR_WS_FUNCTIONS . 'version_checker.php');
      $contribPath = 'http://addons.oscommerce.com/info/3904';
      $currentVersion = 'EasyMap V 3.1';
      $contribName = 'EasyMap V';
      $versionStatus = '';
  }
  /********************** END VERSION CHECKER *********************/
  $activeLang = TEXT_SELECT_A_SPECIAL; //fist time here
  $inputWidth = '30'; //set the width of the input boxes
  $languages = tep_get_languages();
  $selected_special = TEXT_SELECT_A_SPECIAL;
  $special_name = '';
  /********************** CHECK THE VERSION ***********************/
  if (isset($_POST['action']) && $_POST['action'] == 'getversion') {
      if (isset($_POST['version_check']) && $_POST['version_check'] == 'on')
          $versionStatus = AnnounceVersion($contribPath, $currentVersion, $contribName);
  }
  /*********************** HANDLE THE FORM ************************/
  else if (isset($_POST['action']) && $_POST['action'] == 'process') {
      if (isset($_POST['update_form_x'])) {
          $mapsize = tep_db_prepare_input($_POST['mapsize']);
          $maptype = tep_db_prepare_input($_POST['maptype']);
          $markersize = tep_db_prepare_input($_POST['markersize']);
          $markercolor = tep_db_prepare_input($_POST['markercolor']);
          $zoomlevel = (int)($_POST['zoomlevel']);
          $error = false;
          $markerlabel = array();
          $markerLocation = array();
          $pageText = array();
          $street_address = array();
          for($i = 0; $i < count($languages); ++$i) { 
              $street_address[$i] = tep_db_prepare_input($_POST['street_address_'.$i]);
              $markerlabel[$i] = tep_db_prepare_input($_POST['markerlabel_'.$i]);
              $markerlocation[$i] = tep_db_prepare_input($_POST['markerlocation_'.$i]);
              $pageText[$i] = tep_db_prepare_input($_POST['page_text_'.$i]); 
              if (count(explode(',',$markerlabel[$i])) != count(explode('|',$markerlocation[$i]))) {
                  $error = true;
                  $messageStack->add(ERROR_MARKER_COUNT_MISMATCH, 'error');
                  break;
              }
          }
          if (! $error) {
              $sql_data_array = array('mapsize'        =>  (tep_not_null($mapsize) ? tep_db_input($mapsize) : '800x600'),
                                       'maptype'        =>  tep_db_input($maptype),
                                       'markersize'     =>  tep_db_input($markersize),
                                       'markercolor'    =>  tep_db_input($markercolor),
                                       'zoomlevel'      =>  tep_db_input($zoomlevel),
                                      );
              for($i = 0; $i < count($languages); ++$i) { 
                  $em_query = tep_db_query("select 1 from " . TABLE_EASYMAP . " where language_id = " . (int)$languages[$i]['id']); 
                  if (tep_db_num_rows($em_query) > 0)  { //then entry exists
                      $insert_sql_data = array('street_address' =>  tep_db_input($street_address[$i]),
                                               'markerlabel'    =>  (tep_not_null($markerlabel[$i]) ? tep_db_input($markerlabel[$i]) : ''),
                                               'markerlocation' =>  (tep_not_null($markerlocation[$i]) ? tep_db_input($markerlocation[$i]) : ''),
                                               'page_text' => $pageText[$i]
                                               );
                      $sql_data_array = array_merge($sql_data_array, $insert_sql_data);
                      tep_db_perform(TABLE_EASYMAP, $sql_data_array, 'update', "language_id = '" . (int)$languages[$i]['id'] . "'");
                  } else {
                      $insert_sql_data = array('street_address' =>  tep_db_input($street_address[$i]),
                                                'markerlabel'    =>  (tep_not_null($markerlabel[$i]) ? tep_db_input($markerlabel[$i]) : ''),
                                                'markerlocation' =>  (tep_not_null($markerlocation[$i]) ? tep_db_input($markerlocation[$i]) : ''),
                                                'page_text' => $pageText[$i],
                                                'language_id' => $languages[$i]['id'],
                                                'language_name' => $languages[$i]['name']
                                               );
                      $sql_data_array = array_merge($sql_data_array, $insert_sql_data);
                      tep_db_perform(TABLE_EASYMAP, $sql_data_array);
                  }   
              }
          }   
      }
  }
  /********************** CHECK THE VERSION ***********************/
  else if (isset($_POST['action']) && $_POST['action'] == 'getversion') {
      if (isset($_POST['version_check']) && $_POST['version_check'] == 'on')
          $versionStatus = AnnounceVersion($contribPath, $currentVersion, $contribName);
  }
  $map_type_array = array(array('id' => 'roadmap',   'text'  => 'roadmap'),
                           array('id' => 'satellite', 'text'  => 'satellite'),
                           array('id' => 'terrain',   'text'  => 'terrain'),
                           array('id' => 'hybrid',    'text'  => 'hybrid')
                          );
  $map_marker_color_array = array(array('id' => 'black', 'text'  => 'black'),
                                   array('id' => 'brown',  'text'  => 'brown'),
                                   array('id' => 'green',  'text'  => 'green'),
                                   array('id' => 'purple', 'text'  => 'purple'),
                                   array('id' => 'yellow', 'text'  => 'yellow'),
                                   array('id' => 'blue',   'text'  => 'blue'),
                                   array('id' => 'gray',   'text'  => 'gray'),
                                   array('id' => 'orange', 'text'  => 'orange'),
                                   array('id' => 'red',    'text'  => 'red'),
                                   array('id' => 'white ', 'text'  => 'white')
                                  );
  $map_marker_size_array = array(array('id' => 'medium','text'  => 'medium'),
                                 array('id' => 'small',  'text'  => 'small'),
                                 array('id' => 'tiny',   'text'  => 'tiny')
                          );
  $map_zoom_level = array();
  for ($i = 0; $i < 22; ++$i) {
      $map_zoom_level[] = array('id' => $i, 'text'  => $i);
  }     
  /********************* FILL IN FORM WITH SAVED OR PRESETS **********************/
  $emArray = array();
  $em_query = tep_db_query("select * from " . TABLE_EASYMAP); 
  if (tep_db_num_rows($em_query)) {
      while ($emArray[] = tep_db_fetch_array($em_query));
  } else {
      $emArray[$languages[0]['id']]['street_address']  = 'City+Hall,New+York,NY';  
      $emArray[$languages[0]['id']]['mapsize']  = '800x600';  
      $emArray[$languages[0]['id']]['maptype']  = 'roadmap';  
      $emArray[$languages[0]['id']]['markersize']  = 'mid';  
      $emArray[$languages[0]['id']]['markercolor']  = 'blue';  
      $emArray[$languages[0]['id']]['markerlabel']  = 'S';  
      $emArray[$languages[0]['id']]['markerlocation']  = 'City+Hall,New+York,NY';  
      $emArray[$languages[0]['id']]['zoomlevel']  = 14; 
      $emArray[$languages[0]['id']]['page_text'] = TEXT_DEFAULT;     
  }  
?>
<?php
switch (EASYMAP_ENABLE_HTML_EDITOR)
{
   case 'CKEditor':
     echo '<script type="text/javascript" src="./ckeditor/ckeditor.js"></script>';
   break;
   case 'FCKEditor':
   break;
   case 'TinyMCE':
     // START tinyMCE Anywhere
     // Build list of textareas to convert
     $str = "text_home_page,popup_text,";
     $mce_str = rtrim ($str,","); // Removed the last comma from the string.
     // You can add more textareas to convert in the $str, be careful that they are all separated by a comma.
     echo '<script language="javascript" type="text/javascript" src="includes/javascript/tiny_mce/tiny_mce.js"></script>';
     include "includes/javascript/tiny_mce/general.php";
     // END tinyMCE Anywhere 
     break;
     default: break; 
}     
?>
<style type="text/css">
table.BorderedBox {border: ridge #CCFFCC 3px; background-color: #ddd; }
table.BorderedBoxWhite {border: ridge #CCFFCC 3px; background-color: #CCFFCC; }
table.BorderedBoxLight {border: ridge #CCFFCC 3px; background-color: #eee; }
tr.Header { background-color: #CCFFCC; }
.em_small { font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight:bold }
</style>
<?php
  require(DIR_WS_INCLUDES . 'template_top.php');
?>
<table border="0" width="100%" cellspacing="0" cellpadding="0">
  <tr>
    <td width="<?php echo BOX_WIDTH; ?>" valign="top"><table border="0" width="<?php echo BOX_WIDTH; ?>" cellspacing="1" cellpadding="1" class="columnLeft">
     <tr>
      <td><table border="0" width="100%" class="BorderedBoxLight">
      <!-- BEGIN OF EasyMap -->
      <?php echo tep_draw_form('easymap_form', FILENAME_EASYMAP, 'action=process', 'post', 'enctype="multipart/form-data"') . tep_draw_hidden_field('action', 'process'); ?> 
        <tr>
         <td><table border="0" cellpadding="0">
          <tr>
           <td class="em_small" style="text-decoration:underline"><?php echo HEADING_COMMON; ?>:</td>
          </tr>
          <tr> 
           <td colspan="4"><?php echo tep_draw_separator('pixel_trans.gif', '100%', '2'); ?></td>
          </tr>         
          <tr>
           <td class="em_small"><?php echo TEXT_MAP_SIZE; ?></td>
           <td><?php echo tep_draw_input_field('mapsize', $emArray[0]['mapsize'], 'maxlength="255" size="10"', false); ?></td> 
           <td width=<?php echo $spacer; ?></td>
           <td class="smallText"><?php echo TEXT_EXPLAIN_MAP_SIZE; ?></td>
          </tr>
          <tr>
           <td class="em_small"><?php echo TEXT_MAP_ZOOM_LEVEL; ?></td>
           <td class="main"><?php echo tep_draw_pull_down_menu('zoomlevel', $map_zoom_level, $emArray[0]['zoomlevel']); ?></td>
           <td width=<?php echo $spacer; ?></td>
           <td class="smallText"><?php echo TEXT_EXPLAIN_ZOOM_LEVEL; ?></td>
          </tr>
          <tr>
           <td class="em_small"><?php echo TEXT_MAP_TYPE; ?></td>
           <td class="main"><?php echo tep_draw_pull_down_menu('maptype', $map_type_array, $emArray[0]['maptype']); ?></td>
           <td width=<?php echo $spacer; ?></td>
           <td class="smallText"><?php echo TEXT_EXPLAIN_MAP_TYPE; ?></td>
          </tr>
          <tr>
           <td class="em_small"><?php echo TEXT_MAP_MARKER_SIZE; ?></td>
           <td class="main"><?php echo tep_draw_pull_down_menu('markersize', $map_marker_size_array, $emArray[0]['markersize']); ?></td>
           <td width=<?php echo $spacer; ?></td>
           <td class="smallText"><?php echo TEXT_EXPLAIN_MARKER_SIZE; ?></td>
          </tr>
          <tr>
           <td class="em_small"><?php echo TEXT_MAP_MARKER_COLOR; ?></td>
           <td class="main"><?php echo tep_draw_pull_down_menu('markercolor', $map_marker_color_array, $emArray[0]['markercolor']); ?></td>
           <td width=<?php echo $spacer; ?></td>
           <td class="smallText"><?php echo TEXT_EXPLAIN_MARKER_COLOR; ?></td>
          </tr>
         </table></td>
        </tr> 
        <tr>
         <td><table border="0" cellpadding="0">  
          <tr> 
           <td colspan="4"><?php echo tep_draw_separator('pixel_trans.gif', '100%', '10'); ?></td>
          </tr>
          <tr>
           <td colspan="4"><?php echo tep_black_line(); ?></td>
          </tr>          
          <tr> 
           <td colspan="4"><?php echo tep_draw_separator('pixel_trans.gif', '100%', '10'); ?></td>
          </tr>
          <?php for ($i = 0; $i < count($languages); ++$i) { ?>
            <tr>
             <td class="em_small" style="text-decoration:underline"><?php echo $languages[$i]['name']; ?>:</td>
            </tr>
            <tr> 
             <td colspan="4"><?php echo tep_draw_separator('pixel_trans.gif', '100%', '2'); ?></td>
            </tr>
            <tr>
             <td class="em_small" width="102"><?php echo TEXT_MAP_STREET_ADDRESS; ?></td>
             <td><?php echo tep_draw_input_field('street_address_'.$i, $emArray[$i]['street_address'], 'maxlength="255" size="30"', false); ?></td> 
             <td width=<?php echo $spacer; ?></td>
             <td class="smallText"><?php echo TEXT_EXPLAIN_STREET_ADDRESS; ?></td>
            </tr>
            <tr>
             <td class="em_small"><?php echo TEXT_MAP_MARKER_LOCATION; ?></td>
             <td><?php echo tep_draw_input_field('markerlocation_'.$i, $emArray[$i]['markerlocation'], 'maxlength="64" size="30"', false); ?></td> 
             <td width=<?php echo $spacer; ?></td>
             <td class="smallText"><?php echo TEXT_EXPLAIN_MARKER_LOCATION; ?></td>
            </tr>
            <tr>
             <td class="em_small"><?php echo TEXT_MAP_MARKER_LABEL; ?></td>
             <td><?php echo tep_draw_input_field('markerlabel_'.$i, $emArray[$i]['markerlabel'], 'maxlength="5" size="20"', false); ?></td> 
             <td width=<?php echo $spacer; ?></td>
             <td class="smallText"><?php echo TEXT_EXPLAIN_MARKER_LABEL; ?></td>
            </tr>
            <tr>
             <td colspan="4"><table border="0" cellpadding="0" width="100%">
              <tr>
               <td class="em_small" valign="top"><?php echo TEXT_PAGE_TEXT; ?></td>
               <td align="right"><?php echo tep_draw_textarea_field('page_text_'.$i, 'hard', 103, 8, $emArray[$i]['page_text'], '', false); ?></td>
               <td width=<?php echo $spacer; ?></td>
              </tr>
             </table></td>               
            </tr>
            <tr> 
             <td colspan="4"><?php echo tep_draw_separator('pixel_trans.gif', '100%', '10'); ?></td>
            </tr>          
          <?php } ?>
          <tr> 
           <td colspan="4"><?php echo tep_draw_separator('pixel_trans.gif', '100%', '10'); ?></td>
          </tr>
          <tr> 
           <td colspan="4"><?php echo tep_black_line(); ?></td>
          </tr>         
          <tr style="background-color: #dddddd;"> 
           <td align="center" colspan="2"><table border="0" width="65%" cellspacing="0" cellpadding="2">
            <tr>
             <td align="center"><?php echo (tep_image_submit('button_update.gif', IMAGE_UPDATE, 'name="update_form"') ); ?></td>
            </tr>
           </table></td>  
          </tr>        
         </table></td>
        </tr>          
       </form>
       <!-- END OF EasyMap -->
      </table></td>
     </tr>
    </table></td>
  </tr>
</table>
<?php
  require(DIR_WS_INCLUDES . 'template_bottom.php');
  require(DIR_WS_INCLUDES . 'application_bottom.php');
?>