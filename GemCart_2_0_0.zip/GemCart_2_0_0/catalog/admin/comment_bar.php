<?php
/* 
  $Id$ 
  The Gem Cart, the Diamond of E-Commerce shopping cart Solutions 
  TheGemCart, GemCart and The Gem Cart are registered service marks of GemCart Inc. 2012. 
  All rights reserved. 
  http://www.thegemcart.com 
  Copyright 2012 Gem Cart 
  Copyright (c) 2010 osCommerce (portions) 
  Released under the GNU General Public License 
  Version 2.0 2012-05-01 0eth0s & JoDaNo
*/    
// README CONFIGURATION BOF ################################
/*
	There are 3 different button types in the button section,
	Ordering tracking number prompt button, Date prompt button, 
	and regular button. It should not be hard to identify which
	is which as the order and date prompt buttons contain
	more javascript, so you can cut and paste or change these
	buttons to your liking. Do not forget you have to change
	numbers in the button code to select proper order status as well
	(Second number passed to function after TEXT_COMMENT_XX).
*/
// README CONFIGURATION EOF ################################
 require(DIR_WS_LANGUAGES . $language . '/' . FILENAME_COMMENT_BAR);
?>
<!doctype html public "-//W3C//DTD HTML 4.01 Transitional//EN">
<html <?php echo HTML_PARAMS; ?>>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo CHARSET; ?>">
<title><?php echo TITLE; ?></title>
<style type="text/css">
.cbutton { width: 90px; font-family: Verdana; font-size: 9px; padding: 0px; background-color: #FFFFFC; border-bottom: 2px solid #003366; border-right: 1px solid #003366; border-top: 1px solid #003366; border-left: 1px solid #003366; cursor: pointer; cursor: hand; }
</style>
<script language="javascript"><!--
	var usrdate = '';
   function updateComment(obj,statusnum) {
			var textareas = document.getElementsByTagName('textarea');
			var count = document.getElementsByTagName('textarea').length;
			var myTextarea = textareas.item(count-1);
			{
			myTextarea.value = obj;
			}
			var selects = document.getElementsByTagName('select');
			var theSelect = selects.item(0);
			theSelect.selectedIndex = statusnum;
			return false;
   }
   function killbox() {
			var box = document.getElementsByTagName('textarea');
			var killbox = box.item(0);
			killbox.value = '';
			return false;
	}
	function getdate () {
			usrdate = prompt("<?php echo TEXT_PROMPT; ?>"); 
	}
	function getrack () {
			usrtrack = prompt("<?php echo TEXT_TRACKNO; ?>"); 		
	}
//--></script>
</head>
      <table border="0" width="100%" cellspacing="0" cellpadding="0">
		<tr>
			<td colspan="3" align="left" style="font-family: verdana; font-size: 9px; font-weight: bold;">
			<font color="#0033CC">Comments</font><font color="#666666"> Toolbar 4.0&nbsp;</font>
			</td>
		</tr>
      <table border="0" width="50%" cellspacing="0" cellpadding="0">
	  <tr>
<!-- Button Section -->
       <button class="cbutton" onClick="getrack(); return updateComment('<?php echo(TEXT_COMMENT_01); ?>' + usrtrack,'2');"><?php echo TEXT_BUTTON_01; ?></button>&nbsp;
       <button class="cbutton" onClick="getrack(); return updateComment('<?php echo(TEXT_COMMENT_02); ?>' + usrtrack,'2');"><?php echo TEXT_BUTTON_02; ?></button>&nbsp;
       <button class="cbutton" onClick="return updateComment('<?php echo(TEXT_COMMENT_03); ?>','3');"><?php echo TEXT_BUTTON_03; ?></button>&nbsp;
       <button class="cbutton" onClick="getdate(); return updateComment('<?php echo(TEXT_COMMENT_04); ?>' + usrdate,'1');"><?php echo TEXT_BUTTON_04; ?></button>&nbsp;
       <button class="cbutton" onClick="return updateComment('<?php echo(TEXT_COMMENT_05); ?>','0');"><?php echo TEXT_BUTTON_05; ?></button>&nbsp; 
	   <button class="cbutton" onClick="return updateComment('<?php echo(TEXT_COMMENT_06); ?>','0');"><?php echo TEXT_BUTTON_06; ?></button>&nbsp; 
   <button class="cbutton" onClick="return updateComment('<?php echo(TEXT_COMMENT_07); ?>','0');"><?php echo TEXT_BUTTON_07; ?></button>&nbsp; 
       <button class="cbutton" onClick="return updateComment('<?php echo sprintf(TEXT_COMMENT_08, date(DATE_FORMAT)); ?>','1');"><?php echo TEXT_BUTTON_08; ?></button>&nbsp; 
       <button class="cbutton" onClick="return updateComment('<?php echo sprintf(TEXT_COMMENT_09, date(DATE_FORMAT, time()+86400)); ?>','1');"><?php echo TEXT_BUTTON_09; ?></button>&nbsp;
       <button class="cbutton" onClick="return updateComment('<?php echo(TEXT_COMMENT_10); ?>','0');"><?php echo TEXT_BUTTON_10; ?></button>&nbsp;
       <button class="cbutton" onClick="return killbox();"><?php echo TEXT_BUTTON_RESET; ?></button>&nbsp;
		</td>
		</tr>
    </table></td>
<!-- body_text_eof //-->