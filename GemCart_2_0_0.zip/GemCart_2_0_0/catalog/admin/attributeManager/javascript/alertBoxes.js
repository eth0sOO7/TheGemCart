/************************************/

var ALERT_TITLE = "Oops!";
var ALERT_BUTTON_TEXT = "Ok";



