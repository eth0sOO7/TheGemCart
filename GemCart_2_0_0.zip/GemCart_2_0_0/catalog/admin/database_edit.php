<?php
/* 
  $Id$ 
  The Gem Cart, the Diamond of E-Commerce shopping cart Solutions 
  TheGemCart, GemCart and The Gem Cart are registered service marks of GemCart Inc. 2012. 
  All rights reserved. 
  http://www.thegemcart.com 
  Copyright 2012 Gem Cart 
  Copyright (c) 2010 osCommerce (portions) 
  Released under the GNU General Public License 
  Version 2.0 2012-05-01 0eth0s & JoDaNo
*/ 
  require('includes/application_top.php');
  $action = (isset($HTTP_GET_VARS['action']) ? $HTTP_GET_VARS['action'] : '');
	//Create list of all tables
	$result = mysql_query("SHOW TABLES") or die(mysql_error());
	while($row = mysql_fetch_array($result))
	{
	$all_tables[] = $row[0];
	}
	//Make 2x2 array of entries for delete dropdown
	for($i=0; $i<sizeof($all_tables); $i++) {
	  $query = "SELECT * FROM $all_tables[$i]";
		$fieldnames = mysql_query($query) or die(mysql_error());
		$j = 0;
		while ($j < mysql_num_fields($fieldnames)){ 
			$fieldname = mysql_field_name($fieldnames, $j);
			$table_fields[$i][$j]=$fieldname;
			$j++;
		}
	}
	$chosentable = $_POST['tablename'];
?>
<!doctype html public "-//W3C//DTD HTML 4.01 Transitional//EN">
<html <?php echo HTML_PARAMS; ?>>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=<?php echo CHARSET; ?>">
	<title><?php echo TITLE; ?></title>
	<link rel="stylesheet" type="text/css" href="includes/stylesheet.css">
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo CHARSET; ?>">
<title><?php echo TITLE; ?></title>
<link rel="stylesheet" type="text/css" href="includes/stylesheet.css">
</head>
<body marginwidth="0" marginheight="0" topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" bgcolor="#FFFFFF">
<!-- header //-->
<!-- header_eof //-->
<!-- body //-->
<table border="0" width="100%" cellspacing="2" cellpadding="2">
				<?php require(DIR_WS_INCLUDES . 'template_top.php'); ?>
  <tr>
    <td width="<?php echo BOX_WIDTH; ?>" valign="top">
    	<table border="0" width="<?php echo BOX_WIDTH; ?>" cellspacing="1" cellpadding="1" class="columnLeft">
      </table>
    </td>
    <td width="100%" valign="top">
			<!-- Main table for content -->
			<table border="0" width="100%" cellspacing="0" cellpadding="2">
				<tr>
					<td>
						<table border="0" width="100%" cellspacing="0" cellpadding="2">
							<tr>
								<td class="pageHeading"><?php echo HEADING_TITLE; ?>
								</td>
							</tr>
						</table>    	
					</td>
				</tr>
				<tr>
					<td>
					<table border="0" width="100" cellspacing="0" cellpadding="2">
						<form name="mysqlform" method="post" action="database_edit.php">
						<tr>
							<td>
								<select name="tablename">
									<?php
									$num_of_chosen_table=0;
									for ($i = 0; $i <  count($all_tables); $i++) {
    								echo "<option value='$all_tables[$i]'";
    								if ($all_tables[$i] == $chosentable) {
    									echo " selected='selected'";
    									$num_of_chosen_table = $i;
    								}
    								echo ">$all_tables[$i]</option>";
    							}
    							?>
								</select>
							</td>
							<td align="center"><input type="submit" name="submitview" value="View table!" />
							</td>
						</tr>
						<?php
						if($_POST['submitview']) {}
						else echo "</form>";
						?>
					</table>
					</td>
				</tr>
				<?php
				//This php code will perform the actions view, delete and add. 
				if($_POST['submitview']) {
					//MySQL query. Show all from the chosen table.
					$query = "SELECT * FROM " . $chosentable;
					$result = mysql_query($query) or die(mysql_error());
					$num=mysql_numrows($result);
					//Print header
					echo "<tr><table align='left' border='1'>";
					echo "<tr><td colspan='5'><CENTER><B>$chosentable</B></CENTER></td></tr>";
					//Print entry names first
					echo "<tr><td></td>";
					for ($i = 0; $i <  mysql_num_fields($result); $i++) {
						$fieldname = mysql_field_name($result, $i);
						echo "<td>$fieldname</td>";
					}
					echo "</tr>";
					//Print actual entries
					for ($i = 0; $i < $num; $i++) {
						$row = mysql_fetch_row($result);
						echo "<tr>";
						echo "<td><input type='checkbox' name='chkboxarray[]' value=";
						echo $row[0];
						echo "></td>";
						//Get longest string for each colum, so that we can size the input boxes
						for ($j = 0; $j <  count($row); $j++) {
    					echo "<td>$row[$j]</td>";
    					if ($rowlength[$j]<strlen($row[$j])) {
    						$rowlength[$j]=strlen($row[$j]);
    					}
    				}
						echo "</tr>";
					}//End of entry printing
					//If there are no strings for a column, use the length of the field name
					for ($j = 0; $j <  count($table_fields[$num_of_chosen_table]); $j++) {
    				if ($rowlength[$j]<1) {
    					$rowlength[$j]=strlen($table_fields[$num_of_chosen_table][$j]);
    				}   
    			}
					//Make row so that user can add line to table
					echo "<tr>";
					echo "<td><input type='submit' name='submitadd' value='Add' /></td>";
					for ($j = 0; $j <  count($table_fields[$num_of_chosen_table]); $j++) {
    				echo "<td><input type='text' name='newfieldarray[]' size=";
    				echo $rowlength[$j];
    				echo "></td>";
					}
					echo "</tr>";
					//Deletebutton and end of form
					echo "<tr><td><input type='submit' name='submitdelete' value='Delete' /></td></tr>";
					echo "</table></tr>";
					echo "</form>";	
				} //End Post submitview
				if($_POST['submitdelete']) {
					//The MySQl query. Deletes the entries from the database.
					$i=0;
					foreach($_POST['chkboxarray'] as $value) {
						$entryid=$table_fields[$num_of_chosen_table][0];
						$query = "DELETE FROM $chosentable WHERE $entryid = '$value'";
						$result = mysql_query($query) or die(mysql_error());
						$i++;
					}
					echo "The entry/entries has been deleted!";
				} //End Post submitdelete
				if($_POST['submitadd']) {
					$stringtoadd = "'" . $_POST['newfieldarray'][0] . "'";
					for($i=1;$i<count($_POST['newfieldarray']);$i++) {
						$stringtoadd .= ",'" . $_POST['newfieldarray'][$i] . "'";
					}
						$query = "INSERT INTO $chosentable VALUES ($stringtoadd)";
						$result = mysql_query($query) or die(mysql_error());
						echo "The entry has been added!";
				} //End Post submitadd
				?>
			</table>
			<!-- End main table for content -->
		</td> 
	</tr>
</table>
<!-- body_eof //-->
<!-- footer //-->
<?php require(DIR_WS_INCLUDES . 'footer.php'); ?>
<!-- footer_eof //-->
<br>
</body>
</html>
<?php require(DIR_WS_INCLUDES . 'application_bottom.php'); ?>